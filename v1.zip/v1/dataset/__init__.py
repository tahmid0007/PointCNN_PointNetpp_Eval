from . import ModelNet40
from . import shapenet_partseg