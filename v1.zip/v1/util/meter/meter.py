class Meter(object):
    def reset(self):
        pass

    def add(self):
        pass

    def value(self):
        pass
