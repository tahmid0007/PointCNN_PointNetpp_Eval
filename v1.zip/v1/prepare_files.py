import os

dirs = [x[0] for x in os.walk('C:\\Users\\mthossain\\OneDrive - Federation University Australia\\Desktop\\soft study\\Euclideon\\PVCNN\\data\\s3dis\\pointcnn\\Area_1\\')]

for i in range(1,len(dirs)):
    pth_1 = os.path.join(dirs[i], "zero_0.h5").replace('\\','/')
    pth_2 = os.path.join(dirs[i], "half_0.h5").replace('\\','/')
    
    with open('readme.txt', 'a') as f:
        f.write(pth_1)
        f.write('\n')
        f.write(pth_2)
        f.write('\n')
f.close()